# Vindetect.ai Next.js Starter

## Setup

```bash
npm install
npm run dev
```

Open http://localhost:3000 in your browser.
